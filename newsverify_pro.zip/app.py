import streamlit as st
import pickle, re
import nltk
nltk.download('stopwords', quiet=True)
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

ps = PorterStemmer()
stop_words = set(stopwords.words('english'))

def clean_text(text):
    text = re.sub(r'[^a-zA-Z]', ' ', text)
    text = text.lower().split()
    text = [ps.stem(w) for w in text if w not in stop_words]
    return " ".join(text)

# Load model and vectorizer
model = pickle.load(open("model.pkl", "rb"))
tfidf = pickle.load(open("tfidf.pkl", "rb"))

st.set_page_config(page_title="NewsVerify Pro - Hemant Sharma", page_icon=":mag:", layout="centered")
st.markdown("<h1 style='text-align:center;'>🔎 NewsVerify Pro — Hemant Sharma</h1>", unsafe_allow_html=True)
st.markdown("---")

user_input = st.text_area("Paste news article or headline here", height=220, max_chars=5000, placeholder="Enter text to analyze...")

col1, col2 = st.columns([3,1])
with col1:
    st.write("")
with col2:
    if st.button("Analyze"):
        if not user_input.strip():
            st.warning("Please enter some text.")
        else:
            cleaned = clean_text(user_input)
            vec = tfidf.transform([cleaned])
            prob = model.predict_proba(vec)[0]
            label = model.predict(vec)[0]
            conf = max(prob)*100
            if str(label).upper() in ['FAKE','0','FALSE']:
                st.error(f"🚫 Fake News — Confidence: {conf:.2f}%")
            else:
                st.success(f"✅ Real News — Confidence: {conf:.2f}%")

st.markdown("---")
st.markdown("**About:** This is a demo using TF-IDF + LogisticRegression. Not production-grade; for demo/college project use.")